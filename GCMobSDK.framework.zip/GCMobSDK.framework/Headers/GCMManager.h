//
//  GCMManager.h
//  GCMobSDK
//
//  Created by Lan Xuping on 2020/4/30.
//  Copyright © 2020 Lan Xuping. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface GCMManager : NSObject

/// 获取GCMobSDK 版本号
+ (NSString *)getGCMobSDKVersion;

@end

NS_ASSUME_NONNULL_END

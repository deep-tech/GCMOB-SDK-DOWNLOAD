//
//  GCMFullScreenAd.h
//  GCMobSDK
//
//  Created by Lan Xuping on 2020/4/29.
//  Copyright © 2020 Lan Xuping. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIkit.h>
@class GCMFullScreenAd;

@protocol GCMobFullScreenAdDelegate <NSObject>
@optional
/**
 This method is called when video ad material loaded successfully.
 */
- (void)GCMobfullscreenVideoMaterialMetaAdDidLoad:(GCMFullScreenAd *)fullscreenVideoAd;

/**
 This method is called when video ad materia failed to load.
 @param error : the reason of error
 */
- (void)GCMobfullscreenVideoAd:(GCMFullScreenAd *)fullscreenVideoAd didFailWithError:(NSError *)error;

/**
 This method is called when video ad slot will be showing.
 */
- (void)GCMobfullscreenVideoAdWillVisible:(GCMFullScreenAd *)fullscreenVideoAd;

/**
 This method is called when video ad slot has been shown.
 */
- (void)GCMobfullscreenVideoAdDidVisible:(GCMFullScreenAd *)fullscreenVideoAd;

/**
 This method is called when video ad is clicked.
 */
- (void)GCMobfullscreenVideoAdDidClick:(GCMFullScreenAd *)fullscreenVideoAd;

/**
 This method is called when video ad is about to close.
 */
- (void)GCMobfullscreenVideoAdWillClose:(GCMFullScreenAd *)fullscreenVideoAd;

/**
 This method is called when video ad is closed.
 */
- (void)GCMobfullscreenVideoAdDidClose:(GCMFullScreenAd *)fullscreenVideoAd;

/**
 This method is called when video ad playingFinish
 */
- (void)GCMobfullscreenVideoAdPlayingFinish:(GCMFullScreenAd *)fullscreenVideoAd;

@end

@interface GCMFullScreenAd : NSObject
@property (nonatomic, weak) id <GCMobFullScreenAdDelegate> delegate;

- (void)loadFullScreentAdWithToken:(NSString *)token delegate:(id)delegate;
- (void)showFullScreenAdWithViewController:(UIViewController *)viewController;
@end

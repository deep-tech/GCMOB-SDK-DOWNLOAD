//
//  GCMobSDK.h
//  GCMobSDK
//
//  Created by Lan Xuping on 2020/4/29.
//  Copyright © 2020 Lan Xuping. All rights reserved.
//

#import <UIKit/UIKit.h>

#import <GCMobSDK/GCMManager.h>
#import <GCMobSDK/GCMFullScreenAd.h>

//! Project version number for GCMobSDK.
FOUNDATION_EXPORT double GCMobSDKVersionNumber;

//! Project version string for GCMobSDK.
FOUNDATION_EXPORT const unsigned char GCMobSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <GCMobSDK/PublicHeader.h>


